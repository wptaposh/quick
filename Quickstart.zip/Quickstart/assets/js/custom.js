(function ($) {
    "use strict";
    jQuery(document).ready(function ($) {
        var homepageslide = $('.homepage-slides');
        /*==========  owl carousel slider  ==========*/
        homepageslide.owlCarousel({
            items: 1,
            nav: false,
            dots: false,
            autoplay: true,
            loop: true,
            mouseDrag: true,
            touchDrag: false
        });
        /*==========  owl carousel slider effect  ==========*/
        homepageslide.on("translate.owl.carousel", function () {
            $(".h3-bancontent h2").removeClass("animated fadeInUp").css("opacity", "0");
            $(".h3-bancontent h4").removeClass("animated fadeInUp").css("opacity", "0");
            $(".h3-bancontent P").removeClass("animated fadeInUp").css("opacity", "0");
            $(".h3-bancontent .seori-btn").removeClass("animated fadeInUp").css("opacity", "0");
        });
        homepageslide.on("translated.owl.carousel", function () {
            $(".h3-bancontent h2").addClass("animated fadeInUp").css("opacity", "1");
            $(".h3-bancontent h4").addClass("animated fadeInUp").css("opacity", "1");
            $(".h3-bancontent P").addClass("animated fadeInUp").css("opacity", "1");
            $(".h3-bancontent .seori-btn").addClass("animated fadeInUp").css("opacity", "1");
        });
        var serviceslider = $('.service-group');
        /*====================================
			Sidebar Popup JS
		======================================*/ 	
		$('.header-sidebar-icon i').on( "click", function(){
			$('.header-sidebar').addClass('active');
		});
		
		$('.header-sidebar-close').on( "click", function(){
			$('.header-sidebar').removeClass('active');
		});
		
        /*==========  Review Slider  ==========*/
        serviceslider.owlCarousel({
            nav: true,
            dots: false,
            autoplay: true,
            margin: 30,
            loop: true,
            navText: ["<i class='fas fa-angle-left'></i>", "<i class='fas fa-angle-right'></i>"],
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 1
                },
                700: {
                    items: 2
                },
                1000: {
                    items: 3
                }
            }
        });
        var reviewslider = $('.review-group');
        /*==========  Review Slider  ==========*/
        reviewslider.owlCarousel({
            items: 2,
            margin: 30,
            nav: true,
            dots: false,
            autoplay: true,
            loop: true,
             navText: ["<i class='fas fa-angle-left'></i>", "<i class='fas fa-angle-right'></i>"],
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 1
                },
                700: {
                    items: 2
                },
                1000: {
                    items: 2
                }
            }
        });

        /*========== Responsive Menu  ==========*/
        // $("#mobilemenu").slicknav({
        //     prependTo: '#responsive-menu'
        // });
        // meanmenu
        $('#mobile-menu').meanmenu({
            meanMenuContainer: '.mobile-menu',
            meanScreenWidth: "992"
        });
        // /*==========  wow  ==========*/
        new WOW().init();
        /*========== scroll to top  ==========*/
        $(window).on('scroll', function () {
            if ($(this).scrollTop() > 200) {
                $('.scroll-top').fadeIn(200);
            } else {
                $('.scroll-top').fadeOut(200);
            }
        });
        $('.scroll-top').on('click', function (event) {
            event.preventDefault();
            $('html, body').animate({
                scrollTop: 0
            }, 1000);
        });
        /*==========  menu scroll  ==========*/
        $('.menu-right li a').on('click', function (event) {
            $('.menu-right li a').parent().removeClass('active');
            var $anchor = $($(this).attr('href')).offset().top - 70;
            $(this).parent().addClass('active');
            $('body, html').animate({
                scrollTop: $anchor
            }, 800);
            event.preventDefault();
            return false;
        });
        /*==========  menu sticky  ==========*/
        $('.onepage-head').sticky({
            topSpacing: 0
        });
         /*==========  counterUp  ==========*/
        $('.countera').counterUp({
            delay: 100,
            time: 3000
        });
        /*==========  typer  ==========*/
        var typers = $(".typer");
        $(function () {
            typers.typed({
                strings: ["Designer and Developer", "Software Developer"],
                typeSpeed: 15,
                loop: true,
            });
        });

        // data - Background
            $("[data-background]").each(function () {
                $(this).css("background-image", "url(" + $(this).attr("data-background") + ")")
            });
        /*==========  isotop  ==========*/
        jQuery(window).load(function () {
            jQuery(".porlo-loader").fadeOut(500);
            /*========== Project Grid  ==========*/
            var $grid = $('.portfolio-grid').isotope({});
            /*========== Project Filter  ==========*/
            $('.portfolio-filter').on('click', 'li', function () {
                var filterValue = $(this).attr('data-filter');
                $grid.isotope({
                    filter: filterValue
                });
            });
            /*========== Project Active  ==========*/
            $('.portfolio-filter').on('click', 'li', function () {
                $(this).siblings('.active').removeClass('active');
                $(this).addClass('active');
            });
        });
    });
})(jQuery);